Launche The parser.exe 
Thank You